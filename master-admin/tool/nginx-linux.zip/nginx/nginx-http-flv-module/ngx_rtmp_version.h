
/*
 * Copyright (C) Roman Arutyunyan
 * Copyright (C) Winshining
 */


#ifndef _NGX_RTMP_VERSION_H_INCLUDED_
#define _NGX_RTMP_VERSION_H_INCLUDED_


#define nginx_rtmp_version  1002009
#define NGINX_RTMP_VERSION  "1.2.9"


#endif /* _NGX_RTMP_VERSION_H_INCLUDED_ */
